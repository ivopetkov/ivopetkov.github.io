<?php

$app->routes->add('/', function() use ($context) {
    return new \App\Response\HTML('Hi');
});
