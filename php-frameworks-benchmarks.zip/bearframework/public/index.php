<?php

require __DIR__ . '/../vendor/autoload.php';

$app = new App(['appDir' => __DIR__ . '/../app/']);

$app->run();
